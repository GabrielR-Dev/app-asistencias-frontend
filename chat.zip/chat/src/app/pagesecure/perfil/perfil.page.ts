import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { getAuth, signInWithEmailAndPassword,createUserWithEmailAndPassword, signOut, User } from 'firebase/auth';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
  standalone:false,
})
export class PerfilPage implements OnInit {

  private auth = getAuth();
  constructor( private router: Router) { }
  
  async logout(): Promise<void> {
  try {
    await signOut(this.auth);
    this.router.navigate(['/tabs/home']); // 👈 Redirige al login
  } catch (error) {
    console.error('Logout error:', error);
    throw error;
  }
}

  ngOnInit() {
  }

}
