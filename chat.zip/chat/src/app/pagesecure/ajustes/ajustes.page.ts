import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajustes',
  templateUrl: './ajustes.page.html',
  styleUrls: ['./ajustes.page.scss'],
  standalone:false,
})
export class AjustesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
