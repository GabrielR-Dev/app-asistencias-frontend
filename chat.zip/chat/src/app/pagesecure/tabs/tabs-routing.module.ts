import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { TabsPage } from './tabs.page';
import { TabsPage } from '../../pagesecure/tabs/tabs.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'homesecure',
        loadChildren: () => import('../../pagesecure/home/home.module').then(m => m.HomePageModuleSecure)
      },
      {
        path: 'ajustesecure',
        loadChildren: () => import('../../pagesecure/ajustes/ajustes.module').then(m => m.AjustesPageModuleSecure)
      },
      {
        path: 'perfilsecure',
        loadChildren: () => import('../../pagesecure/perfil/perfil.module').then(m => m.PerfilPageModuleSecure)
      },
      {
        path: '',
        redirectTo: '/tabs/homesecure',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabsPageRoutingModuleSecure {}